import React, { useState, useEffect } from 'react';
import { 
  MoreHorizontal, Star, Mail, Phone, MapPin, Calendar, DollarSign, 
  Building2, Clock, CheckCircle2, XCircle, AlertCircle, FileText, 
  Tag, Users, MessageSquare, Globe, ChevronDown, User 
} from 'lucide-react';
import { Lead } from '../../types/leads';
import LeadActionsMenu from './LeadActionsMenu';
import toast from 'react-hot-toast';

interface LeadListProps {
  leads: Lead[];
  onLeadClick: (lead: Lead) => void;
  viewMode: 'list' | 'grid';
}

interface LeadNotification {
  type: 'email_opened' | 'booking_confirmed' | 'booking_cancelled' | 'message_received';
  timestamp: string;
}

const statusColors = {
  new: 'bg-blue-50 text-blue-700 ring-blue-600/20 dark:bg-blue-900/50 dark:text-blue-200',
  contacted: 'bg-yellow-50 text-yellow-700 ring-yellow-600/20 dark:bg-yellow-900/50 dark:text-yellow-200',
  qualified: 'bg-green-50 text-green-700 ring-green-600/20 dark:bg-green-900/50 dark:text-green-200',
  proposal: 'bg-purple-50 text-purple-700 ring-purple-600/20 dark:bg-purple-900/50 dark:text-purple-200',
  won: 'bg-emerald-50 text-emerald-700 ring-emerald-600/20 dark:bg-emerald-900/50 dark:text-emerald-200',
  lost: 'bg-red-50 text-red-700 ring-red-600/20 dark:bg-red-900/50 dark:text-red-200',
};

const statusIcons = {
  new: AlertCircle,
  contacted: Clock,
  qualified: Star,
  proposal: FileText,
  won: CheckCircle2,
  lost: XCircle,
};

export default function LeadList({ leads, onLeadClick, viewMode }: LeadListProps) {
  const [activeMenu, setActiveMenu] = useState<{ id: string; position: { top: number; left: number } } | null>(null);
  const [expandedLeads, setExpandedLeads] = useState<string[]>([]);
  const [notifications] = useState<Record<string, LeadNotification[]>>({});

  const handleActionClick = (e: React.MouseEvent, lead: Lead) => {
    e.stopPropagation();
    e.preventDefault();
    const rect = e.currentTarget.getBoundingClientRect();
    setActiveMenu({
      id: lead.id,
      position: {
        top: rect.top + window.scrollY,
        left: rect.left + window.scrollX
      }
    });
  };

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (activeMenu) {
        setActiveMenu(null);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [activeMenu]);
  const handleDelete = async (lead: Lead) => {
    // TODO: Implement delete functionality
    toast.error('Delete functionality not implemented yet');
  };

  const handleArchive = async (lead: Lead) => {
    // TODO: Implement archive functionality
    toast.error('Archive functionality not implemented yet');
  };

  if (viewMode === 'grid') {
    return (
      <div className="divide-y divide-gray-200 dark:divide-gray-700">
        {leads.map((lead) => (
          <div
            key={lead.id}
            onClick={() => onLeadClick(lead)} 
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 dark:bg-primary/5 flex items-center justify-center">
                  <span className="text-lg font-medium text-gray-600 dark:text-gray-300">
                    {lead.name[0].toUpperCase()}
                  </span>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                    {lead.name}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {lead.company || 'No company'}
                  </p>
                </div>
              </div>
              <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ring-1 ring-inset ${statusColors[lead.status]}`}>
                {React.createElement(statusIcons[lead.status], { className: 'w-3 h-3' })}
                {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
              </span>
            </div>

            <div className="space-y-2">
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <Mail className="w-4 h-4 mr-2 flex-shrink-0" />
                {lead.email}
              </div>
              {lead.phone && (
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <Phone className="w-4 h-4 mr-2 flex-shrink-0" />
                  {lead.phone}
                </div>
              )}
              <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                {lead.country}
              </div>
              {lead.budget && (
                <div className="flex items-center text-sm font-medium text-gray-900 dark:text-white">
                  <DollarSign className="w-4 h-4 mr-1 flex-shrink-0" />
                  {lead.budget.toLocaleString()}
                </div>
              )}
            </div>
            <button
              onClick={(e) => handleActionClick(e, lead)}
              className="p-1 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors"
            >
              <MoreHorizontal className="w-5 h-5" />
            </button>
            {activeMenu?.id === lead.id && (
              <LeadActionsMenu
                lead={lead}
                onClose={() => setActiveMenu(null)}
                onDelete={() => handleDelete(lead)}
                onArchive={() => handleArchive(lead)}
                position={activeMenu.position}
              />
            )}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="overflow-x-auto divide-y divide-gray-200 dark:divide-gray-700">
      {leads.map((lead) => (
        <div key={lead.id} className="flex flex-col sm:hidden p-4 space-y-3">
          {/* Mobile Lead Card */}
          <div 
            onClick={() => setExpandedLeads(prev => 
              prev.includes(lead.id) 
                ? prev.filter(id => id !== lead.id)
                : [...prev, lead.id]
            )}
            className="flex items-center justify-between"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-lg font-medium text-gray-600 dark:text-gray-300">
                  {lead.name[0].toUpperCase()}
                </span>
              </div>
              <div>
                <h3 className="font-medium text-gray-900 dark:text-white">{lead.name}</h3>
                <p className="text-sm text-gray-500">{lead.company || 'No company'}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <span className={`px-2 py-1 text-xs rounded-full ${statusColors[lead.status]}`}>
                {lead.status}
              </span>
              <ChevronDown className={`w-4 h-4 transition-transform ${
                expandedLeads.includes(lead.id) ? 'rotate-180' : ''
              }`} />
            </div>
          </div>

          {/* Expanded Content */}
          {expandedLeads.includes(lead.id) && (
            <div className="pl-13 space-y-3 animate-slideDown">
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Mail className="w-4 h-4" />
                  {lead.email}
                </div>
                {lead.phone && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Phone className="w-4 h-4" />
                    {lead.phone}
                  </div>
                )}
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <User className="w-4 h-4" />
                  Assigned to: {lead.assigned_to || 'Unassigned'}
                </div>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <Clock className="w-4 h-4" />
                  Last contacted: {lead.last_contact ? new Date(lead.last_contact).toLocaleDateString() : 'Never'}
                </div>
              </div>

              {/* Notifications */}
              {notifications[lead.id]?.length > 0 && (
                <div className="border-t border-gray-200 dark:border-gray-700 pt-2 mt-2">
                  <h4 className="text-sm font-medium text-gray-900 dark:text-white mb-2">Recent Activity</h4>
                  <div className="space-y-2">
                    {notifications[lead.id].map((notification, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm text-gray-600">
                        <div className="w-2 h-2 rounded-full bg-primary" />
                        {notification.type.replace('_', ' ')} • {new Date(notification.timestamp).toLocaleDateString()}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center gap-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                <button className="flex-1 px-3 py-1.5 text-sm text-primary border border-primary rounded-lg">
                  Send Email
                </button>
                <button className="flex-1 px-3 py-1.5 text-sm text-primary border border-primary rounded-lg">
                  Call
                </button>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleActionClick(e, lead);
                  }}
                  className="p-1.5 text-gray-400 hover:text-gray-600 rounded-lg"
                >
                  <MoreHorizontal className="w-5 h-5" />
                </button>
              </div>
            </div>
          )}

          {/* Desktop View */}
          <tr key={lead.id} className="hidden sm:table-row hover:bg-gray-50 dark:hover:bg-gray-700/50">
            <td className="px-4 py-4">
              <div className="flex items-center gap-3">
                <div className="flex-shrink-0 h-10 w-10 rounded-full bg-primary/10 dark:bg-primary/5 flex items-center justify-center">
                  <span className="text-lg font-medium text-gray-600 dark:text-gray-300">
                    {lead.name[0].toUpperCase()}
                  </span>
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-900 dark:text-white truncate">
                    {lead.name}
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {lead.company || 'No company'}
                  </p>
                </div>
              </div>
            </td>
            <td className="px-4 py-4">
              <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ring-1 ring-inset ${statusColors[lead.status]}`}>
                {React.createElement(statusIcons[lead.status], { className: 'w-3 h-3' })}
                {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
              </span>
            </td>
            <td className="px-4 py-4">
              <div className="flex flex-col gap-1">
                <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                  <Mail className="w-4 h-4 mr-2" />
                  {lead.email}
                </div>
                {lead.phone && (
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <Phone className="w-4 h-4 mr-2" />
                    {lead.phone}
                  </div>
                )}
              </div>
            </td>
            <td className="px-4 py-4">
              <div className="flex items-center text-sm text-gray-900 dark:text-white">
                <DollarSign className="w-4 h-4 mr-1" />
                {lead.budget ? lead.budget.toLocaleString() : '-'}
              </div>
            </td>
            <td className="px-4 py-4 text-right">
              <button
                onClick={(e) => handleActionClick(e, lead)}
                className="p-1 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors"
              >
                <MoreHorizontal className="w-5 h-5" />
              </button>
              {activeMenu?.id === lead.id && (
                <LeadActionsMenu
                  lead={lead}
                  onClose={() => setActiveMenu(null)}
                  onDelete={() => handleDelete(lead)}
                  onArchive={() => handleArchive(lead)}
                  position={activeMenu.position}
                />
              )}
            </td>
          </tr>
        </div>
      ))}
    </div>
  ); 
}